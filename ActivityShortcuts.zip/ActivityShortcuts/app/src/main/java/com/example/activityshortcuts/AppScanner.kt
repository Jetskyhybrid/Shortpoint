package com.example.activityshortcuts

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

data class AppEntry(val label: String, val packageName: String)

data class ActivityEntry(val name: String, val className: String)

object AppScanner {

    /** System screens offered as presets: name to intent action. */
    val settingsPresets: List<Pair<String, String>> = listOf(
        "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
        "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
        "Mobile data / roaming" to Settings.ACTION_DATA_ROAMING_SETTINGS,
        "Airplane mode" to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        "Display" to Settings.ACTION_DISPLAY_SETTINGS,
        "Sound" to Settings.ACTION_SOUND_SETTINGS,
        "Battery saver" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
        "Location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        "Accessibility" to Settings.ACTION_ACCESSIBILITY_SETTINGS,
        "Date & time" to Settings.ACTION_DATE_SETTINGS,
        "Language" to Settings.ACTION_LOCALE_SETTINGS,
        "All apps" to Settings.ACTION_APPLICATION_SETTINGS,
        "Developer options" to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
        "Security" to Settings.ACTION_SECURITY_SETTINGS,
        "VPN" to Settings.ACTION_VPN_SETTINGS,
    )

    fun launchableApps(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(main, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(main, 0)
        }
        return infos
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    /** Screens of an app that other apps are allowed to open (exported + enabled). */
    fun activitiesOf(context: Context, packageName: String): List<ActivityEntry> {
        val pm = context.packageManager
        val info = try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(
                    packageName,
                    PackageManager.PackageInfoFlags.of(PackageManager.GET_ACTIVITIES.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES)
            }
        } catch (e: Exception) {
            return emptyList()
        }
        val launcher = pm.getLaunchIntentForPackage(packageName)?.component?.className
        return info.activities.orEmpty()
            .filter { it.exported && it.isEnabled }
            .map {
                ActivityEntry(
                    if (it.name == launcher) "Open app (main screen)" else it.name.substringAfterLast('.'),
                    it.name
                )
            }
            .sortedWith(
                compareByDescending<ActivityEntry> { it.className == launcher }
                    .thenBy { it.name.lowercase() }
            )
    }
}
