package com.example.activityshortcuts

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max

/**
 * Floating "#" bubble that stays on top of other apps.
 * Tap it to open a calculator-style keypad: type a task number, press Run.
 * Drag the bubble (or the keypad title) to move it.
 */
class FloatingService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var panel: LinearLayout? = null
    private var numberView: TextView? = null
    private var labelView: TextView? = null
    private var entry = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        addBubble()
        running = true
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { safeRemove(it) }
        bubble = null
        running = false
        super.onDestroy()
    }

    // ---------- foreground notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating button", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Floating shortcuts are on")
            .setContentText("Tap Stop to remove the floating button")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null as Icon?, "Stop", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun safeRemove(v: View) {
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
    }

    // ---------- bubble ----------

    private fun addBubble() {
        val size = dp(56)
        val b = TextView(this).apply {
            text = "#"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF3D5AFE.toInt())
            }
            elevation = dp(6).toFloat()
        }
        bubbleParams = overlayParams().apply {
            width = size
            height = size
            x = dp(8)
            y = dp(200)
        }
        b.setOnTouchListener(DragListener(b, bubbleParams) { togglePanel() })
        wm.addView(b, bubbleParams)
        bubble = b
    }

    private fun togglePanel() {
        if (panel == null) showPanel() else hidePanel()
    }

    // ---------- keypad panel ----------

    private fun showPanel() {
        if (panel != null) return
        val panelWidth = dp(240)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), 0xFFCCCCCC.toInt())
            }
            elevation = dp(8).toFloat()
        }

        // header: drag handle + collapse
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "Task keypad (drag here)"
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, dp(6), 0, dp(6))
        }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val close = TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(Color.DKGRAY)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { hidePanel() }
        }
        header.addView(close)
        root.addView(header)

        // display
        numberView = TextView(this).apply {
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.END
            setTextColor(Color.BLACK)
        }
        labelView = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.END
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(Color.DKGRAY)
        }
        root.addView(numberView)
        root.addView(labelView)

        // keys
        root.addView(keyRow(digitKey("7"), digitKey("8"), digitKey("9")))
        root.addView(keyRow(digitKey("4"), digitKey("5"), digitKey("6")))
        root.addView(keyRow(digitKey("1"), digitKey("2"), digitKey("3")))
        root.addView(
            keyRow(
                key("C") { entry = ""; refresh() },
                key("0") { if (entry.isNotEmpty() && entry.length < 4) { entry += "0"; refresh() } },
                key("⌫") { entry = entry.dropLast(1); refresh() }
            )
        )
        val run = key("Run") { runEntry() }
        root.addView(
            run,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)).apply {
                setMargins(dp(2), dp(4), dp(2), dp(2))
            }
        )
        val remove = TextView(this).apply {
            text = "Remove floating button"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFFB00020.toInt())
            setPadding(0, dp(8), 0, dp(2))
            setOnClickListener { stopSelf() }
        }
        root.addView(remove)

        val screen = resources.displayMetrics
        val p = overlayParams().apply {
            width = panelWidth
            x = bubbleParams.x.coerceIn(0, max(0, screen.widthPixels - panelWidth))
            y = (bubbleParams.y + dp(64)).coerceIn(0, max(0, screen.heightPixels - dp(420)))
        }
        title.setOnTouchListener(DragListener(root, p, null))
        wm.addView(root, p)
        panel = root
        refresh()
    }

    private fun hidePanel() {
        panel?.let { safeRemove(it) }
        panel = null
        numberView = null
        labelView = null
        entry = ""
    }

    private fun key(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 18f
        setOnClickListener { onClick() }
    }

    private fun digitKey(d: String) = key(d) {
        if (entry.length < 4) {
            entry += d
            refresh()
        }
    }

    private fun keyRow(vararg keys: Button) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        keys.forEach {
            addView(it, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                setMargins(dp(2), dp(2), dp(2), dp(2))
            })
        }
    }

    private fun refresh() {
        numberView?.text = if (entry.isEmpty()) "0" else entry
        labelView?.text = if (entry.isEmpty()) {
            "Type a task number"
        } else {
            TaskStore(this).get(entry.toIntOrNull() ?: -1)?.label ?: "No task $entry"
        }
    }

    private fun runEntry() {
        val code = entry.toIntOrNull() ?: return
        val task = TaskStore(this).get(code)
        if (task == null) {
            Toast.makeText(this, "No task with code $code", Toast.LENGTH_SHORT).show()
            return
        }
        hidePanel()
        TaskLauncher.run(this, task)
    }

    // ---------- dragging ----------

    private inner class DragListener(
        private val view: View,
        private val params: WindowManager.LayoutParams,
        private val onTap: (() -> Unit)?,
    ) : View.OnTouchListener {
        private val slop = ViewConfiguration.get(this@FloatingService).scaledTouchSlop
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        params.x = startX + dx
                        params.y = startY + dy
                        try {
                            wm.updateViewLayout(view, params)
                        } catch (_: Exception) {
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                }
            }
            return true
        }
    }

    companion object {
        const val ACTION_STOP = "com.example.activityshortcuts.STOP_FLOATING"
        private const val CHANNEL = "floating"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false
    }
}
