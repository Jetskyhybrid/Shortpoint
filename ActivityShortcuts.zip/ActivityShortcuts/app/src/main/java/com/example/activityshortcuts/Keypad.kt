package com.example.activityshortcuts

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/**
 * Calculator-style window: tap digits to type a task number,
 * the display shows which task it is, Run opens it.
 */
@Composable
fun Keypad(tasks: List<Task>) {
    val context = LocalContext.current
    var entry by remember { mutableStateOf("") }
    val code = entry.toIntOrNull()
    val match = code?.let { c -> tasks.firstOrNull { it.code == c } }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    if (entry.isEmpty()) "0" else entry,
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    when {
                        entry.isEmpty() -> "Type a task number"
                        match != null -> match.label
                        else -> "No task $entry"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        listOf(
            listOf("7", "8", "9"),
            listOf("4", "5", "6"),
            listOf("1", "2", "3"),
        ).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { digit ->
                    Key(digit) { if (entry.length < 4) entry += digit }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Key("C") { entry = "" }
            Key("0") { if (entry.isNotEmpty() && entry.length < 4) entry += "0" }
            Key("⌫") { entry = entry.dropLast(1) }
        }

        Button(
            onClick = { match?.let { TaskLauncher.run(context, it) } },
            enabled = match != null,
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("Run", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
private fun RowScope.Key(label: String, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        modifier = Modifier
            .weight(1f)
            .height(64.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(label, style = MaterialTheme.typography.headlineSmall)
    }
}
