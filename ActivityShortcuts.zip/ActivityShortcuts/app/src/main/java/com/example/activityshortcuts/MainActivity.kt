package com.example.activityshortcuts

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Switch
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF3D5AFE))) {
                Surface(Modifier.fillMaxSize()) { AppRoot() }
            }
        }
    }
}

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val store = remember { TaskStore(context) }
    var tasks by remember { mutableStateOf(store.all()) }
    var picking by remember { mutableStateOf(false) }

    fun reload() {
        tasks = store.all()
        ShortcutHelper.refreshDynamic(context, tasks)
    }

    LaunchedEffect(Unit) { ShortcutHelper.refreshDynamic(context, tasks) }

    BackHandler(enabled = picking) { picking = false }

    if (picking) {
        PickerScreen(
            store = store,
            onSaved = {
                picking = false
                reload()
            },
            onCancel = { picking = false }
        )
    } else {
        HomeScreen(
            tasks = tasks,
            store = store,
            onAdd = { picking = true },
            onChanged = { reload() }
        )
    }
}

@Composable
fun HomeScreen(
    tasks: List<Task>,
    store: TaskStore,
    onAdd: () -> Unit,
    onChanged: () -> Unit,
) {
    val context = LocalContext.current
    var view by remember { mutableIntStateOf(0) } // 0 keypad, 1 grid, 2 list
    var selected by remember { mutableStateOf<Task?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) {
                Text("+", style = MaterialTheme.typography.headlineMedium)
            }
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .padding(16.dp)
        ) {
            Text("Activity Shortcuts", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))

            // Floating button that stays over other apps
            var floatingOn by remember { mutableStateOf(FloatingService.running) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Floating button", Modifier.weight(1f))
                Switch(
                    checked = floatingOn,
                    onCheckedChange = { on ->
                        if (on) {
                            if (!Settings.canDrawOverlays(context)) {
                                Toast.makeText(
                                    context,
                                    "Allow \"Display over other apps\", then switch on again",
                                    Toast.LENGTH_LONG
                                ).show()
                                context.startActivity(
                                    Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                )
                            } else {
                                context.startForegroundService(
                                    Intent(context, FloatingService::class.java)
                                )
                                floatingOn = true
                            }
                        } else {
                            context.stopService(Intent(context, FloatingService::class.java))
                            floatingOn = false
                        }
                    }
                )
            }

            Spacer(Modifier.height(8.dp))

            TabRow(selectedTabIndex = view) {
                Tab(selected = view == 0, onClick = { view = 0 }, text = { Text("Keypad") })
                Tab(selected = view == 1, onClick = { view = 1 }, text = { Text("Grid") })
                Tab(selected = view == 2, onClick = { view = 2 }, text = { Text("List") })
            }

            Spacer(Modifier.height(12.dp))

            if (view == 0) {
                // Calculator-style: type a number, see the task, press Run
                Keypad(tasks)
            } else if (tasks.isEmpty()) {
                Text("No tasks yet. Tap + to create task 1.")
            } else if (view == 1) {
                // Every task number in one window: tap = run, long-press = pin / delete
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(88.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    gridItems(tasks, key = { it.code }) { task ->
                        NumberTile(
                            task = task,
                            onRun = { TaskLauncher.run(context, task) },
                            onMore = { selected = task }
                        )
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(tasks, key = { it.code }) { task ->
                        TaskCard(task, store, onChanged)
                    }
                }
            }

            selected?.let { t ->
                AlertDialog(
                    onDismissRequest = { selected = null },
                    title = { Text("${t.code}: ${t.label}") },
                    text = { Text(t.target()) },
                    confirmButton = {
                        TextButton(onClick = {
                            if (!ShortcutHelper.pin(context, t)) {
                                Toast.makeText(
                                    context,
                                    "Your launcher can't pin shortcuts",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                            selected = null
                        }) { Text("Pin to home") }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            store.delete(t.code)
                            ShortcutHelper.remove(context, t.code)
                            selected = null
                            onChanged()
                        }) { Text("Delete") }
                    }
                )
            }
        }
    }
}

@Composable
private fun TaskCard(task: Task, store: TaskStore, onChanged: () -> Unit) {
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(44.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        task.code.toString(),
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(task.label, style = MaterialTheme.typography.titleMedium)
                    Text(task.target(), style = MaterialTheme.typography.bodySmall)
                }
            }
            Row {
                TextButton(onClick = { TaskLauncher.run(context, task) }) { Text("Run") }
                TextButton(onClick = {
                    if (!ShortcutHelper.pin(context, task)) {
                        Toast.makeText(
                            context,
                            "Your launcher can't pin shortcuts",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }) { Text("Pin to home") }
                TextButton(onClick = {
                    store.delete(task.code)
                    ShortcutHelper.remove(context, task.code)
                    onChanged()
                }) { Text("Delete") }
            }
        }
    }
}
