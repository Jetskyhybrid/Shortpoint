package com.example.activityshortcuts

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun PickerScreen(store: TaskStore, onSaved: () -> Unit, onCancel: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var draft by remember { mutableStateOf<Task?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onCancel) { Text("Back") }
            Text("Pick a screen", style = MaterialTheme.typography.titleLarge)
        }
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Apps") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("System settings") })
        }
        if (tab == 0) {
            AppsList(onPick = { draft = it })
        } else {
            SettingsList(onPick = { draft = it })
        }
    }

    draft?.let { d ->
        SaveDialog(
            draft = d,
            store = store,
            onSave = {
                store.save(it)
                draft = null
                onSaved()
            },
            onDismiss = { draft = null }
        )
    }
}

@Composable
private fun AppsList(onPick: (Task) -> Unit) {
    val context = LocalContext.current
    val apps by produceState(emptyList<AppEntry>()) {
        value = withContext(Dispatchers.Default) { AppScanner.launchableApps(context) }
    }
    var expanded by remember { mutableStateOf<String?>(null) }

    LazyColumn(Modifier.fillMaxSize()) {
        items(apps, key = { it.packageName }) { app ->
            Column {
                Text(
                    app.label,
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            expanded = if (expanded == app.packageName) null else app.packageName
                        }
                        .padding(16.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
                if (expanded == app.packageName) {
                    val screens = remember(app.packageName) {
                        AppScanner.activitiesOf(context, app.packageName)
                    }
                    if (screens.isEmpty()) {
                        Text(
                            "No screens this app allows opening",
                            Modifier.padding(start = 32.dp, bottom = 12.dp),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    screens.forEach { screen ->
                        Text(
                            screen.name,
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onPick(
                                        Task(
                                            code = 0,
                                            label = "${app.label} - ${screen.name}",
                                            packageName = app.packageName,
                                            className = screen.className
                                        )
                                    )
                                }
                                .padding(start = 32.dp, top = 10.dp, end = 16.dp, bottom = 10.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun SettingsList(onPick: (Task) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        items(AppScanner.settingsPresets, key = { it.second }) { (name, action) ->
            Column {
                Text(
                    name,
                    Modifier
                        .fillMaxWidth()
                        .clickable { onPick(Task(code = 0, label = name, action = action)) }
                        .padding(16.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun SaveDialog(
    draft: Task,
    store: TaskStore,
    onSave: (Task) -> Unit,
    onDismiss: () -> Unit,
) {
    var codeText by remember { mutableStateOf(store.nextFreeCode().toString()) }
    var label by remember { mutableStateOf(draft.label) }
    val code = codeText.toIntOrNull()
    val exists = code != null && store.get(code) != null

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Save as numbered task") },
        text = {
            Column {
                OutlinedTextField(
                    value = codeText,
                    onValueChange = { codeText = it.filter(Char::isDigit).take(4) },
                    label = { Text("Code (number)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                if (exists) {
                    Text(
                        "Code $code is already used and will be replaced.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Name") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = code != null && code > 0 && label.isNotBlank(),
                onClick = { if (code != null) onSave(draft.copy(code = code, label = label.trim())) }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
