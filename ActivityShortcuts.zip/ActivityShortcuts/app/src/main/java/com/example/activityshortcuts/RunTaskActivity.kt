package com.example.activityshortcuts

import android.app.Activity
import android.os.Bundle

/** Invisible activity that runs the numbered task from a pinned/dynamic shortcut, then closes. */
class RunTaskActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val code = intent.getIntExtra(TaskLauncher.EXTRA_CODE, -1)
        if (code >= 0) TaskLauncher.run(this, code)
        finish()
    }
}
