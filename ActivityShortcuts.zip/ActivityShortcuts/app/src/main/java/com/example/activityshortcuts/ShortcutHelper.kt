package com.example.activityshortcuts

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

object ShortcutHelper {

    private fun idFor(code: Int) = "task_$code"

    private fun build(context: Context, task: Task): ShortcutInfoCompat {
        val intent = Intent(context, RunTaskActivity::class.java).apply {
            action = TaskLauncher.ACTION_RUN
            putExtra(TaskLauncher.EXTRA_CODE, task.code)
        }
        return ShortcutInfoCompat.Builder(context, idFor(task.code))
            .setShortLabel("${task.code} ${task.label}")
            .setLongLabel("${task.code}: ${task.label}")
            .setIcon(IconCompat.createWithBitmap(numberIcon(task.code.toString())))
            .setIntent(intent)
            .build()
    }

    /** Asks the launcher to pin this task to the home screen. */
    fun pin(context: Context, task: Task): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) return false
        return ShortcutManagerCompat.requestPinShortcut(context, build(context, task), null)
    }

    /** Long-press menu on the app icon shows the first few tasks. */
    fun refreshDynamic(context: Context, tasks: List<Task>) {
        try {
            val max = ShortcutManagerCompat.getMaxShortcutCountPerActivity(context).coerceAtMost(4)
            ShortcutManagerCompat.setDynamicShortcuts(
                context,
                tasks.take(max).map { build(context, it) }
            )
        } catch (_: Exception) {
        }
    }

    fun remove(context: Context, code: Int) {
        val ids = listOf(idFor(code))
        try {
            ShortcutManagerCompat.removeDynamicShortcuts(context, ids)
            ShortcutManagerCompat.disableShortcuts(context, ids, "This task was deleted")
        } catch (_: Exception) {
        }
    }

    /** Round icon showing the task number. */
    private fun numberIcon(text: String): Bitmap {
        val size = 192
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3D5AFE.toInt() }
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, bg)
        val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
            textSize = when (text.length) {
                1, 2 -> 110f
                3 -> 80f
                else -> 60f
            }
        }
        val y = size / 2f - (fg.descent() + fg.ascent()) / 2f
        canvas.drawText(text, size / 2f, y, fg)
        return bmp
    }
}
