package com.example.activityshortcuts

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * One numbered task. It opens either a specific screen of an app
 * (packageName + className) or a system action (action).
 */
data class Task(
    val code: Int,
    val label: String,
    val packageName: String? = null,
    val className: String? = null,
    val action: String? = null,
) {
    fun target(): String = when {
        className != null -> "$packageName/${className.substringAfterLast('.')}"
        else -> action?.substringAfterLast('.') ?: ""
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("code", code)
        put("label", label)
        packageName?.let { put("pkg", it) }
        className?.let { put("cls", it) }
        action?.let { put("action", it) }
    }

    companion object {
        fun fromJson(o: JSONObject) = Task(
            code = o.getInt("code"),
            label = o.getString("label"),
            packageName = o.optString("pkg", "").ifEmpty { null },
            className = o.optString("cls", "").ifEmpty { null },
            action = o.optString("action", "").ifEmpty { null },
        )
    }
}

/** Stores tasks as JSON in SharedPreferences. */
class TaskStore(context: Context) {
    private val prefs =
        context.applicationContext.getSharedPreferences("tasks", Context.MODE_PRIVATE)

    fun all(): List<Task> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length())
                .map { Task.fromJson(arr.getJSONObject(it)) }
                .sortedBy { it.code }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun get(code: Int): Task? = all().firstOrNull { it.code == code }

    fun save(task: Task) {
        write(all().filterNot { it.code == task.code } + task)
    }

    fun delete(code: Int) {
        write(all().filterNot { it.code == code })
    }

    fun nextFreeCode(): Int {
        val used = all().map { it.code }.toSet()
        var n = 1
        while (n in used) n++
        return n
    }

    private fun write(list: List<Task>) {
        val arr = JSONArray()
        list.sortedBy { it.code }.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    private companion object {
        const val KEY = "tasks"
    }
}
