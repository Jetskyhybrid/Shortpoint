package com.example.activityshortcuts

import android.content.Context
import android.content.Intent
import android.widget.Toast

object TaskLauncher {
    const val ACTION_RUN = "com.example.activityshortcuts.RUN_TASK"
    const val EXTRA_CODE = "code"

    private fun buildIntent(task: Task): Intent? = when {
        task.packageName != null && task.className != null ->
            Intent().setClassName(task.packageName, task.className)
        task.action != null -> Intent(task.action)
        else -> null
    }

    fun run(context: Context, code: Int): Boolean {
        val task = TaskStore(context).get(code)
        if (task == null) {
            Toast.makeText(context, "No task with code $code", Toast.LENGTH_SHORT).show()
            return false
        }
        return run(context, task)
    }

    fun run(context: Context, task: Task): Boolean {
        val intent = buildIntent(task) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            // Screens that aren't exported (or were removed) can't be opened without root.
            Toast.makeText(
                context,
                "Can't open \"${task.label}\" (${e.javaClass.simpleName})",
                Toast.LENGTH_LONG
            ).show()
            false
        }
    }
}
